function exploreMore() {
    window.location.href = "#categories";
}
